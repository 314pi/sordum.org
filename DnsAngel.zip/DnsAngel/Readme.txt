Author: Velociraptor , BlueLife
www.sordum.org

@@@@@@@@@@@@@@@@@@@@--Dns Angel v1.6 (16.11.2018)--@@@@@@@@@@@@@@@@@@@@

What is New
1. [Added] - Reading dns from .ini file (You can edit ini file to add your own family safe dns ips)
2. [Added] - Change Dns with Tab + Enter keyboard shortcut
3. [Added] - Some code improvements (quick response)

@@@@@@@@@@@@@@@@@@@@--Dns Angel v1.5 (17.05.2017)--@@@@@@@@@@@@@@@@@@@@

What is New
1. Some minor Bugs fixed


@@@@@@@@@@@@@@@@@@@@--Dns Angel v1.4 (08.07.2015)--@@@@@@@@@@@@@@@@@@@@

What is New
1. Metacert Dns deleted


@@@@@@@@@@@@@@@@@@@@--Dns Angel v1.3 (20.01.2014)--@@@@@@@@@@@@@@@@@@@@

What is New
1. Norton DNS ips Updated
2. Yandex Dns added


@@@@@@@@@@@@@@@@@@@@--Dns Angel v1.2 (27.07.2013)--@@@@@@@@@@@@@@@@@@@@

What is New
1. Button desing improved
2. F�XED - Metacert �nclude only one DNS
3. Default and Restore buttons functions improved
4. Some minor Bugs fixed

@@@@@@@@@@@@@@@@@@@@--Dns Angel v1.1 (28.01.2013)--@@@@@@@@@@@@@@@@@@@@

What is New
- Restore DNS Button added
- A small design error corrected


@@@@@@@@@@@@@@@@@@@@--Dns Angel v1.0 (26.01.2013)--@@@@@@@@@@@@@@@@@@@@

What is New
- �nclude 3 DNS Service to Block Adult websites (Porn Sites) , Malicious sites ,Phishing sites, malware websites
- You can see your current DNS and it�s status (Safe or not)
- You dont need to install it (it is Portable)
- You don�t need to Flush DSN ( Dns Angel v1.0 Flushs dns cache Automatically)
- You can easily remove Child protection (just click �Default DNS button�)
- It is very simle and effective

