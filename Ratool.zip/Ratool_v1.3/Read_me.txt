Author: BlueLife , Velociraptor 
www.sordum.org

@@@@@@@@@@@@@@@@@@@@--Ratool v1.3--@@@@@@@@@@@@@@@@@@@@
(Thursday , 21. May 2015)

What is new:
1. [Fixed] - After Block All usb Storege devices , if you use "non used usb device" , 
it resets all the restrictions - Lock settings should be chosen  (Critical)
2. [Fixed] - inaccessibility of Usbstor service causes ownership problem (rare)
3. [Fixed] - Some minor BUGS
4. [Added] - "Prevent Installation of USB Devices" feature added , this feature allows you 
Block all  USB Devices except yours (like white list)

@@@@@@@@@@@@@@@@@@@@--Ratool v1.2--@@@@@@@@@@@@@@@@@@@@
(Sunday, 07. September 2014) 

What is new:
1. [Fixed] - Mount Point label Bug
2. [Fixed] - Show hidden Files on the drive feture causing freezing and crash
3. [Fixed] - Show hidden Files on the drive process can not interrupted
4. [Fixed] - Show hidden Files on the drive feture doesn't support external HDD
5. [Fixed] - Disable Autorun take effect only after log off or restart
6. [Fixed] - Translate GUI bugs

@@@@@@@@@@@@@@@@@@@@--Ratool v1.1--@@@@@@@@@@@@@@@@@@@@
(Sunday, 17. August 2014) 

What is new:
1. [Fixed] - Removable Access tool has stopped working
2. [Added] - Language Support
3. [Added] - Password hint
4. [Added] - Write the password in asterisk
5. [Added] - F1 , F5 keyboard shortcuts
6. [Added] - Extra Protection for Windows 7 and Above
7. [Added] - separately protection function for Cd-dvd, flopy, tape and wpd drives (Not for xp)


@@@@@@@@@@@@@@@@@@@@--Ratool v1.0--@@@@@@@@@@@@@@@@@@@@
(Thursday, 2. May 2013) 

Features:
1. You can disable USB disk detection
2. You can set your USB storage / PenDrive Read-Only
3. You can Allow Read & Write (Default)
4. You can disable USB Autorun
5. You can Safely remove Hardware
6. You can Show hidden files on selected drive
7. You can Lock the settings
8. Show hidden files on selected drive