Author: BlueLife , Velociraptor
www.sordum.org


<><><><><><><><><><> Reset Data Usage v1.2 (Monday, 29.May 2017) <><><><><><><><><><> 

What is New :

1. [ Fixed ] - Except English language , After using "Data Usage" button , button language reset itself to English
2. [ Fixed ] - On special occasions, for example if username and computer name are the same , Backup manager doesn't work

<><><><><><><><><><> Reset Data Usage v1.1 (Wednesday, 24.May 2017) <><><><><><><><><><> 

What is New :

1. [ Fixed ] - Sometimes "Reset Data usage" does not work properly
2. [ Added ] - Backup and Restore feature
3. [ Added ] - Fix Data usage feature
4. [ Added ] - Language Support


<><><><><><><><><><> Reset Data Usage v1.0 (Friday, 5.May 2017) <><><><><><><><><><> 

First release to reset or clear the network data usage with One click