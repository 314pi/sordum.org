Author: BlueLife, Velociraptor
www.sordum.org

###################--Edge Blocker v1.4--###################
(Tuesday, 25. April 2017)

[ Fixed ] - EDGE Blocker Corrupt Microsoft EDGE in �Windows 10 version 1703� Most probably it is a Microsoft BUG � Critical

###################--Edge Blocker v1.3--###################
(Saturday, 11. November 2016)

[Added] - Extra block mechanism


###################--Edge Blocker v1.2--###################
(Monday, 09. May 2016)

[ Fixed ] - EDGE Blocker Doesn't work on some Windows 10 versions (especially x64 Home verison)

###################--Edge Blocker v1.1--###################
(Friday, 01. April 2016)

Changelog:

[ Fixed ] - First Block attempt in first run takes long time
[ Fixed ] - Some code improvements and Minor Bug fixes
[ Added ] - Create a internet explorer shortcut on desktop feature

---------------------------------------------------------------

###################--Edge Blocker v1.0--###################
(Wednesday, 27. January 2016)


you can block or unblock the Edge browser, very simple GUI
so no super skills are required to work with it
once you�ve blocked the browser, it won�t load
