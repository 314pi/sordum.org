Author: BlueLife
www.sordum.org


---------------- Bpuzzle v1.1 ---------------------
(21.01.1014)

Changelog:

1. [Added] - Keyboard Arrow key support (to play the Game You can use Arrow keys on the keyboard)
2. [Fixed] - Some minor Bugs
3. [Fixed] - False Positive Issue


---------------- Bpuzzle v1.0 ---------------------
(11.04.2013)

bPuzzle is a simple game which is played by moving pieces one place to another(true) place. 
It has 5 difficulty levels.