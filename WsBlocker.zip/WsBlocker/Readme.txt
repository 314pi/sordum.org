Author: BlueLife , Velociraptor
www.sordum.org


---------------- Win10 Settings Blocker v1.1 ---------------------
(November 10, 2018)

Changelog:

1. [Added] - Hide specified control panel items
2. [Added] - Export - Import Feature
3. [Added] - Some code improvements

---------------- Win10 Settings Blocker v1.0 ---------------------
(October 26, 2018)

To stop users from changing settings in Windows 10 you can lock down individual Settings panes and 
Control Panel items with Win10 Settings Blocker Application. It is a Portable freeware