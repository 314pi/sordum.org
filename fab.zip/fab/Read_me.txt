Author: BlueLife , Velociraptor
www.sordum.org

[010101010101010101]--Firewall App Blocker (Fab) v1.6--[010101010101010101]

(Friday , 21. April 2017)
------------
Changelog:
01. FIXED - Add a folder feature doesn't support shortcuts 
02. FIXED - If the firewall is closed, added icons seems to be blocked
03. FIXED - In whitelist mode MS Edge continues to establish normal connections to the Internet (Need extra step)
04. FIXED - Fab cannot remove old versions Context Menu registry entries properly


[010101010101010101]--Firewall App Blocker (Fab) v1.5--[010101010101010101]

(07.02.2017)
------------
Changelog:
01. FIXED - Fab Add a block rule unnecessarily Outbound and Inbound sections together 
02. FIXED - When adding a Block rule Fab disable Firewall and enable it again 
03. FIXED - To block An application "Apply" button must be used (every time) 
04. FIXED - Some minor BUGS ,GUI desing and much more...
05. ADDED - Outbound and inbound lists separated
06. ADDED - Block Process feature
07. ADDED - whitelist mode feature
08. ADDED - Add a folder feature (All exe in the folder will be Automatically blocked)
09. ADDED - Block internet feature
10. ADDED - Restrict Firewall Access feature
11. ADDED - Disable Firewall feature
12. ADDED - Resizable application window
13. ADDED - Change the font feature
14. ADDED - Status indicator feature 
15. ADDED - Firewall App Blocker X64 exe


[010101010101010101]--Firewall App Blocker (Fab) v1.4--[010101010101010101]   

(29.08.2014)
------------
Changelog:
1. ADDED - Language support
2. ADDED - Exe Context Menu (you can easily right click any program and block it in Windows Firewall)
3. FIXED - Button design
4. FIXED - Some code improvements

[010101010101010101]--Firewall App Blocker (Fab) v1.3--[010101010101010101]

(23.07.2013)
------------
Changelog:
1. FIXED � Drag and Drop doesn't work properly
2. FIXED � After adding 10 + Application RAM usage is starting to rise
3. FIXED � Some minor BUGS
4. FIXED � Firewall App blocker (Fab) uses only Outbound Rules (not Inbound)
5. ADDED � Export / Import Feture
6. ADDED � Cmd Support
7. ADDED � Reset Firewall Settings
8. Re-coded
9. New design


[010101010101010101]--Firewall App Blocker (Fab) v1.2 Beta--[010101010101010101]

(15.05.2012)
------------
Changelog:
1. F�XED - Shortcut drag and drop problem
2. F�XED - Folder drag and drop problem

[010101010101010101]--Firewall App Blocker (Fab) v1.1 Beta--[010101010101010101]

(14.05.2012)
-------------
Changelog:
1. F�XED - If you have ESET security product on your system , Firewall App Blocker does not working properly
2. F�XED - A small bug fixed
3. ADDED - Auto Language selection (Only English and Turkish)