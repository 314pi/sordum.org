Author: BlueLife , Velociraptor
www.sordum.org

@@@@@@@@@@@@@@@@@@@@--BlueLife Hosts Editor v1.2--@@@@@@@@@@@@@@@@@@@@
(Wednesday, 09. April 2014)

Changelog:

[ Fixed ] � If the attributes of the hosts file changed to system , Save function doesn't work


@@@@@@@@@@@@@@@@@@@@--BlueLife Hosts Editor v1.1--@@@@@@@@@@@@@@@@@@@@
(Friday, 27. September 2013)

Changelog:

1. BlueLife Hosts Editor v1.1 completely Rewritten
2. [ Fixed ] � Hosts editor doesn�t work properly on Windows 8
3. [ Added ] � Import � Export options
4. [ Added ] � Automatically add other prefix to domains
5. [ Added ] � Backup manager
6. [ Added ] � Command Line Parameters support
7. [ Added ] � Dns Cilent Service Options (Disable,Stop,Restart)
8. [ Added ] � View as table or text
9. [ Added ] � Resolve domain options
10.[ Added ] � You can easily open another hosts or text file
11.[ Added ] � Replace Ip options
12.[ Added ] � Consecutive domain ban option
13.[ Added ] � Flush Dns option
14.[ Added ] � Change Font Options and much more � 


@@@@@@@@@@@@@@@@@@@@--BlueLife Hosts Editor v1.0--@@@@@@@@@@@@@@@@@@@@
(Monday, 30. October 2011)

- Add domain names to your hosts file
- Delete domain names
- Block domain names
- Update active ip adresses
- Open the domain name with default browser
- Flush Dns
- Rebuild default windows hosts
- Backup your hosts file
- Restore your hosts file
- Open hosts file with notepad function